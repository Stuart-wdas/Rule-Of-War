"""Build an editable, animated volumetric explosion in Blender 4.5.

blender -b --factory-startup --disable-autoexec --python build_spiky_explosion.py
Optional arguments after --: --render-qa or --render-all
This is an authored particle/volume animation, not a baked fluid simulation.
"""
import bpy
import json
import math
import random
import sys
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent
FPS, FIRST, LAST = 24, 1, 64
random.seed(20817)

def smooth(x):
    x = min(1., max(0., x))
    return x*x*(3-2*x)

def interval(x, a, b):
    return smooth((x-a)/(b-a))

def volume_material(name, fire=False, tip=False):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    nodes.clear()
    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (960,0)
    shader = nodes.new('ShaderNodeVolumePrincipled')
    shader.location = (690,0)
    shader.inputs['Color'].default_value = (.12,.10,.085,1) if not fire else (.12,.035,.005,1)
    shader.inputs['Anisotropy'].default_value = .18
    links.new(shader.outputs['Volume'],output.inputs['Volume'])
    coords=nodes.new('ShaderNodeTexCoord'); coords.location=(-1000,0)
    coarse=nodes.new('ShaderNodeTexNoise'); coarse.location=(-780,190)
    coarse.noise_dimensions='4D'
    coarse.inputs['Scale'].default_value = 3.7 if fire else 3.15
    coarse.inputs['Detail'].default_value=4.
    coarse.inputs['Roughness'].default_value=.72
    coarse.inputs['W'].default_value=0.
    coarse.inputs['W'].keyframe_insert('default_value',frame=FIRST)
    coarse.inputs['W'].default_value=1.15 if fire else .64
    coarse.inputs['W'].keyframe_insert('default_value',frame=LAST)
    links.new(coords.outputs['Generated'],coarse.inputs['Vector'])
    ramp=nodes.new('ShaderNodeValToRGB');ramp.location=(-530,210)
    ramp.color_ramp.elements[0].position=.37 if fire else .43
    ramp.color_ramp.elements[1].position=.63 if fire else .59
    links.new(coarse.outputs['Fac'],ramp.inputs[0])
    distance=nodes.new('ShaderNodeVectorMath');distance.operation='DISTANCE';distance.location=(-780,-120)
    distance.inputs[1].default_value=(.5,.5,.5)
    # Warp the radial falloff with a second noise field, giving irregular edges.
    warp_noise=nodes.new('ShaderNodeTexNoise');warp_noise.location=(-1000,-430)
    warp_noise.inputs['Scale'].default_value=4.6
    warp_noise.inputs['Detail'].default_value=3
    links.new(coords.outputs['Generated'],warp_noise.inputs['Vector'])
    centered=nodes.new('ShaderNodeVectorMath');centered.operation='SUBTRACT'
    centered.inputs[1].default_value=(.5,.5,.5)
    links.new(warp_noise.outputs['Color'],centered.inputs[0])
    scaled=nodes.new('ShaderNodeVectorMath');scaled.operation='SCALE'
    scaled.inputs['Scale'].default_value=.65
    links.new(centered.outputs['Vector'],scaled.inputs[0])
    warped=nodes.new('ShaderNodeVectorMath');warped.operation='ADD'
    links.new(coords.outputs['Generated'],warped.inputs[0]);links.new(scaled.outputs['Vector'],warped.inputs[1])
    links.new(warped.outputs['Vector'],distance.inputs[0])
    edge=nodes.new('ShaderNodeMapRange');edge.location=(-530,-130)
    edge.clamp=True
    edge.inputs['From Min'].default_value=.22
    edge.inputs['From Max'].default_value=.48
    edge.inputs['To Min'].default_value=1
    edge.inputs['To Max'].default_value=0
    links.new(distance.outputs['Value'],edge.inputs[0])
    obj=nodes.new('ShaderNodeObjectInfo');obj.location=(-540,-420)
    multiply=nodes.new('ShaderNodeMath');multiply.operation='MULTIPLY';multiply.location=(-240,100)
    links.new(ramp.outputs['Color'],multiply.inputs[0]);links.new(edge.outputs[0],multiply.inputs[1])
    opacity=nodes.new('ShaderNodeMath');opacity.operation='MULTIPLY';opacity.location=(-30,100)
    links.new(multiply.outputs[0],opacity.inputs[0]);links.new(obj.outputs['Alpha'],opacity.inputs[1])
    density=nodes.new('ShaderNodeMath');density.operation='MULTIPLY';density.location=(200,60)
    density.inputs[1].default_value=12. if not fire else 2.5
    links.new(opacity.outputs[0],density.inputs[0]);links.new(density.outputs[0],shader.inputs['Density'])
    if fire:
        color=nodes.new('ShaderNodeValToRGB');color.location=(-200,350)
        cr=color.color_ramp
        cr.elements[0].position=.25;cr.elements[0].color=(.6,.025,.001,1)
        cr.elements[1].position=.82;cr.elements[1].color=(1,.78,.26,1)
        cr.elements.new(.58).color=(1,.17,.005,1)
        links.new(coarse.outputs['Fac'],color.inputs[0])
        links.new(color.outputs['Color'],shader.inputs['Emission Color'])
        strength=nodes.new('ShaderNodeMath');strength.operation='MULTIPLY';strength.location=(400,300)
        strength.inputs[1].default_value=65. if tip else 35.
        links.new(opacity.outputs[0],strength.inputs[0])
        links.new(strength.outputs[0],shader.inputs['Emission Strength'])
    return mat

def particle(name, material, collection):
    o=bpy.data.objects.new(name,SPHERE)
    collection.objects.link(o)
    # Object-linked materials allow a shared low-poly volume boundary mesh.
    if not o.material_slots:
        SPHERE.materials.append(material)
    o.material_slots[0].link='OBJECT';o.material_slots[0].material=material
    o['description']='Animated volume particle; color alpha controls density/emission'
    return o

def key(o,f,position,scale,alpha):
    o.location=position
    o.scale=tuple(max(.0001,v) for v in scale)
    o.color=(1,1,1,max(0.,min(1.,alpha)))
    o.keyframe_insert('location',frame=f)
    o.keyframe_insert('scale',frame=f)
    o.keyframe_insert('color',frame=f)

def collection(name):
    c=bpy.data.collections.new(name);bpy.context.scene.collection.children.link(c);return c

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
scene=bpy.context.scene
scene.frame_start=FIRST;scene.frame_end=LAST;scene.render.fps=FPS
scene.render.engine='CYCLES'
scene.render.use_persistent_data=True
scene.cycles.samples=40
scene.cycles.use_denoising=True
scene.cycles.use_adaptive_sampling=True
scene.cycles.adaptive_threshold=.08
scene.cycles.volume_step_rate=2.
scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA'
scene.render.image_settings.color_depth='8'
scene.render.film_transparent=True
scene.view_settings.view_transform='AgX'
scene.render.image_settings.compression=20
scene.render.use_file_extension=True
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type='OPTIX';prefs.get_devices()
    gpu=False
    for device in prefs.devices:
        device.use=device.type!='CPU'
        gpu=gpu or device.use
    if gpu:scene.cycles.device='GPU'
except Exception:
    pass

bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1)
template=bpy.context.object;SPHERE=template.data;SPHERE.name='Shared volume boundary (80 triangles)'
bpy.data.objects.remove(template,do_unlink=True)
fire_mat=volume_material('Fire - short central burst',fire=True)
tip_mat=volume_material('Fire - compact projectile tips',fire=True,tip=True)
smoke_mat=volume_material('Smoke - turbulent absorbing volume')
core_c=collection('01 - Brief central fireball')
tip_c=collection('02 - Fire tips launched INSIDE core')
trail_c=collection('03 - Smoke wakes along projectile paths')
body_c=collection('04 - Rolling central smoke')
debris_c=collection('05 - Small debris')

# The main flame has a short lifetime; smoke carries the remaining animation.
for j in range(9):
    direction=Vector((random.uniform(-1,1),random.uniform(-1,1),random.uniform(-.2,1))).normalized()
    r=random.uniform(.5,.85)
    o=particle(f'Core flame lobe {j+1:02}',fire_mat,core_c)
    for f in range(FIRST,LAST+1):
        growth=interval(f,1,10)
        fade=1-interval(f,10,21)
        extent=.35+.8*growth
        pos=Vector((0,0,1.35))+direction*extent*.65
        sz=r*(.12+1.4*growth)
        key(o,f,pos,(sz,sz*.9,sz*1.05),interval(f,1,4)*fade)

# Dense smoke lobes billow from the same explosion center and rise slowly.
for j in range(17):
    az=random.uniform(0,2*math.pi);rad=random.uniform(.25,1.35)
    o=particle(f'Central smoke lobe {j+1:02}',smoke_mat,body_c)
    delay=random.uniform(5,12);base=random.uniform(.5,.9)
    for f in range(FIRST,LAST+1):
        t=max(0,(f-delay)/FPS)
        spread=1-math.exp(-t*2.5)
        pos=(math.cos(az)*rad*spread,math.sin(az)*rad*spread,1.15+random.Random(j).uniform(0,.5)+t*.55)
        sz=base*(.25+1.4*spread+t*.22)
        a=interval(f,delay,delay+9)*(1-interval(f,40,64))
        key(o,f,pos,(sz,sz*.95,sz*1.15),a)

spikes=[]
for j in range(11):
    az=(j/11)*2*math.pi+random.uniform(-.17,.17)
    elevation=random.uniform(.72,1.12)
    direction=Vector((math.cos(az)*math.cos(elevation),math.sin(az)*math.cos(elevation),math.sin(elevation)))
    launch=5+j%4;speed=random.uniform(16.,21.)
    origin=Vector((0,0,1.25))+direction*random.uniform(.06,.22)
    def trajectory(t,origin=origin,direction=direction,speed=speed):
        # Exact ballistic motion under linear drag: quick outward/upward launch,
        # then gravity bends the tip and its deposited wake back towards earth.
        drag,gravity=.28,18.
        travel=-math.expm1(-drag*t)/drag
        return origin+direction*(speed*travel)+Vector((0,0,-gravity*(t-travel)/drag))
    spikes.append(dict(id=j+1,launch_frame=launch,origin=list(origin),direction=list(direction),speed=speed,
                       elevation_radians=elevation,gravity=18.,linear_drag=.28))
    tip=particle(f'Spike {j+1:02} - burning tip',tip_mat,tip_c)
    tip['launch_frame']=launch;tip['launch_origin']=list(origin)
    tip['motion']='Fast elevated launch from inside core; gravity and drag create a descending arc; smoke follows actual path'
    # A small tip, never an entire streak of fire.
    for f in range(FIRST,LAST+1):
        t=max(0,(f-launch)/FPS)
        position=trajectory(t)
        a=interval(f,launch,launch+2)*(1-interval(f,launch+15,launch+28))*interval(position.z,.12,.5)
        size=.19*(1-.45*min(t,1))
        key(tip,f,position,(size,size,size*1.22),a)
    # Deposit particles at positions the tip actually occupied, oldest at base.
    for p in range(12):
        born=launch+p*2.1
        sample_t=(born-launch)/FPS
        birth=trajectory(sample_t)+Vector((random.uniform(-.08,.08),random.uniform(-.08,.08),random.uniform(-.06,.1)))
        variation=random.uniform(.72,1.3)
        o=particle(f'Spike {j+1:02} - smoke trail {p+1:02}',smoke_mat,trail_c)
        tangent=(trajectory(sample_t+.02)-trajectory(max(0.,sample_t-.02))).normalized()
        o.rotation_euler=tangent.to_track_quat('Z','Y').to_euler()
        segment_length=(trajectory(sample_t+2.1/FPS)-trajectory(sample_t)).length
        o['emission_frame']=born;o['emission_position']=list(birth)
        for f in range(FIRST,LAST+1):
            age=max(0,(f-born)/FPS)
            size=(.24+age*.32)*(1+.012*p)*variation
            drift=Vector((math.sin(j*7.3+p)*age*.11,math.cos(j*3.7+p)*age*.11,age*.4))
            a=interval(f,born,born+2)*(1-interval(age,.4,1.35))*(1-interval(f,48,62))
            length=max(size*1.15,segment_length*.95+age*.15)
            key(o,f,birth+drift,(size,size*.95,length),a*.9)

# Debris is deliberately sparse and dark; it is not extra flame.
mat=bpy.data.materials.new('Charred debris');mat.diffuse_color=(.045,.032,.02,1)
for j in range(15):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1)
    o=bpy.context.object;o.name=f'Debris {j+1:02}'
    for c in list(o.users_collection):c.objects.unlink(o)
    debris_c.objects.link(o);o.data.materials.append(mat)
    az=random.uniform(0,math.tau);speed=random.uniform(2,6);up=random.uniform(2,5)
    size=random.uniform(.015,.045)
    for f in range(FIRST,LAST+1):
        t=max(0,(f-8)/FPS)
        visible=interval(f,7,9)*(1-interval(f,33,43))
        key(o,f,(math.cos(az)*speed*t,math.sin(az)*speed*t,1.2+up*t-3*t*t),(size*visible,size*.7*visible,size*1.3*visible),1)

world=bpy.data.worlds.new('Neutral studio environment');world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.16,.18,.21,1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45;scene.world=world
for name,pos,power,size in [('Key',(3,-5,10),1800,7),('Fill',(-5,2,5),850,6),('Rim',(0,6,8),1400,5)]:
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
    o=bpy.data.objects.new(name,data);scene.collection.objects.link(o);o.location=pos
    o.rotation_euler=(Vector((0,0,1.5))-o.location).to_track_quat('-Z','Y').to_euler()
data=bpy.data.lights.new('Brief explosion illumination','POINT');data.color=(1,.22,.025);data.shadow_soft_size=1.2
o=bpy.data.objects.new('Brief explosion illumination',data);scene.collection.objects.link(o);o.location=(0,0,1.4)
for f,power in [(1,0),(5,300),(10,900),(20,0),(64,0)]:data.energy=power;data.keyframe_insert('energy',frame=f)

data=bpy.data.cameras.new('Preview orthographic camera')
camera=bpy.data.objects.new('Preview orthographic camera',data);scene.collection.objects.link(camera)
camera.location=(12,-18,12)
target=Vector((0,0,3.2));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
data.type='ORTHO';data.ortho_scale=24.;scene.camera=camera
scene['effect_description']='Short central fireball; 11 fast elevated ballistic arcs launched from inside it; compact fire tips with curved dark smoke wakes'
scene['technique']='Procedural animated 3D volume particles, not a CFD/fluid bake; no external assets or simulation caches'
scene['playback']='Frames 1-64 at 24 fps, play once (2.6667 seconds)'
scene.timeline_markers.new('Ignition',frame=2)
scene.timeline_markers.new('Fast high spikes launch INSIDE ball',frame=5)
scene.timeline_markers.new('Fire tips arc back / smoke trails',frame=24)
scene.timeline_markers.new('Smoke takes over',frame=26)
scene.timeline_markers.new('Dissipated',frame=64)

# Frame samples are fully keyed, with linear interpolation to prevent overshoot.
for action in bpy.data.actions:
    try:
        for fc in action.fcurves:
            for k in fc.keyframe_points:k.interpolation='LINEAR'
    except AttributeError:pass

ROOT.mkdir(parents=True,exist_ok=True)
scene.frame_set(18)
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_perspective='CAMERA'
        area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'spiky_explosion.blend'))
(ROOT/'effect.json').write_text(json.dumps(dict(name='spiky_explosion',technique=scene['technique'],fps=FPS,frames=64,
    duration_seconds=64/FPS,spike_count=len(spikes),spikes=spikes,source='Authored locally; not extracted from the game',
    frame_order='Frames 1..64; atlas left-to-right then top-to-bottom',alpha='RGBA PNG, straight alpha',
    main_fire_fade_end_frame=21,tip_fire_duration_frames=28,
    trajectory='Ballistic arcs under gravity 18 units/s^2 and linear drag 0.28/s; launch speed 16-21 units/s at 41-64 degrees'),indent=2)+'\n')
# Engine-neutral 3D particle tracks: genuine positions, not rendered billboards.
tracks=[]
for c,kind in [(core_c,1),(tip_c,2),(trail_c,0),(body_c,0)]:
    for o in c.objects:
        samples=[]
        for f in range(FIRST,LAST+1):
            scene.frame_set(f)
            samples.extend([round(v,5) for v in (*o.location,*o.scale,o.color[3])])
        axis=o.rotation_euler.to_quaternion()@Vector((0,0,1))
        tracks.append(dict(name=o.name,kind=kind,axis=[round(v,6) for v in axis],samples=samples))
(ROOT/'particle_tracks.json').write_text(json.dumps(dict(fps=FPS,frames=64,stride=7,
    axes='Blender: X right, Y forward, Z up',fields=['x','y','z','scaleX','scaleY','scaleZ','opacity'],particles=tracks),separators=(',',':'))+'\n')
scene.frame_set(18)
print('SCENE_READY',ROOT/'spiky_explosion.blend',flush=True)
if '--render-qa' in sys.argv or '--render-all' in sys.argv:
    (ROOT/'frames').mkdir(exist_ok=True)
    frames=range(FIRST,LAST+1) if '--render-all' in sys.argv else [8,18,30,46]
    for f in frames:
        scene.frame_set(f);scene.render.filepath=str(ROOT/'frames'/f'frame_{f:03}.png')
        bpy.ops.render.render(write_still=True)
        print('FRAME_DONE',f,flush=True)
