"""Pack this effect's renders, previews and standalone ZIP without rewriting other effects."""
import argparse,hashlib,json,math,subprocess,zipfile
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
PACK=ROOT.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def included(p):return p.is_file() and p.suffix!='.blend1' and '__pycache__' not in p.parts and p.name!='qa_contact.jpg'
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ffmpeg',required=True)
    parser.add_argument('--archive',type=Path,default=PACK.parent.parent/'Spiky_Explosion_3D.zip')
    args=parser.parse_args()
    frames=[]
    for f in range(1,65):
        with Image.open(ROOT/'frames'/f'frame_{f:03}.png') as im:
            assert im.mode=='RGBA' and im.size==(512,512);frames.append(im.copy())
    assert frames[0].getchannel('A').getextrema()==(0,0)
    assert frames[-1].getchannel('A').getextrema()==(0,0)
    sheets=[]
    for size in [4096,2048]:
        cell=size//8;sheet=Image.new('RGBA',(size,size))
        for i,frame in enumerate(frames):
            im=frame if cell==512 else frame.resize((cell,cell),Image.Resampling.LANCZOS)
            alpha=im.getchannel('A')
            for box in [(0,0,cell,1),(0,cell-1,cell,cell),(0,0,1,cell),(cell-1,0,cell,cell)]:
                assert alpha.crop(box).getextrema()[1]==0
            sheet.paste(im,((i%8)*cell,(i//8)*cell))
        p=ROOT/f'spiky_explosion_8x8_{size}.png';sheet.save(p)
        sheets.append(dict(path=p.relative_to(PACK).as_posix(),resolution=[size,size],cell_size=[cell,cell],sha256=sha(p)))
    try:font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',23)
    except OSError:font=ImageFont.load_default()
    def compose(i):
        im=Image.new('RGB',(960,720),(41,49,58));d=ImageDraw.Draw(im)
        d.text((32,22),'SPIKY EXPLOSION | 3D remake',fill='white',font=font)
        d.text((32,58),'Fast high launch / arcing fire tips / trailing smoke',fill=(192,200,207),font=font)
        if i%80<64:
            rgba=frames[i%80].resize((600,600),Image.Resampling.LANCZOS);im.paste(rgba,(180,84),rgba)
        d.text((32,682),'64 frames | 24 fps | 2.667 seconds | Native Blender scene included',fill=(192,200,207),font=font)
        return im
    compose(24).save(ROOT/'preview.jpg',quality=94)
    contact=Image.new('RGB',(1024,1056),(55,63,72));d=ImageDraw.Draw(contact)
    for j,f in enumerate([8,18,30,46]):
        x=(j%2)*512;y=(j//2)*528+16;im=frames[f-1];contact.paste(im,(x,y),im)
        d.text((x+12,y-15),f'Frame {f}',fill='white')
    contact.save(ROOT/'contact_sheet.jpg',quality=94)
    video=ROOT/'spiky_explosion_preview.mp4'
    cmd=[args.ffmpeg,'-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','960x720','-r','24','-i','-',
         '-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(video)]
    with subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.DEVNULL) as proc:
        for i in range(160):proc.stdin.write(compose(i).tobytes())
        proc.stdin.close();assert proc.wait()==0
    decoded=subprocess.run([args.ffmpeg,'-hide_banner','-i',str(video),'-f','null','-'],capture_output=True,text=True)
    assert decoded.returncode==0
    tracks=json.loads((ROOT/'particle_tracks.json').read_text())
    assert len(tracks['particles'])==169 and all(len(p['samples'])==448 for p in tracks['particles'])
    assert all(math.isfinite(x) for p in tracks['particles'] for x in p['samples'])
    assert json.loads((ROOT/'scene_validation.json').read_text())['status']=='PASS'
    validation=dict(status='PASS',native_scene_reopened=True,png_frames=64,png_mode='RGBA',sprite_sheets=sheets,
        first_last_frames_fully_transparent=True,frame_cell_outer_borders_fully_transparent=True,
        frame_order='Left to right, top to bottom',fps=24,duration_seconds=64/24,
        video=dict(decoded=True,dimensions=[960,720],fps=24,frames=160,duration_seconds=160/24,audio=False),
        engine_adapter=dict(particle_tracks=169,finite_transforms=True,native_bevy_motion_tests='PASS',
            node_runtime_playback='NOT RUN for this revision; optional Three.js adapter',
            browser_shader_test='NOT RUN: standalone Three.js adapter remains experimental; native Bevy renderer checked separately'),
        provenance='Authored procedural volume remake, not extracted from game and not fluid-simulated')
    (ROOT/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    meta=json.loads((ROOT/'effect.json').read_text());meta.update(id='spiky_explosion',files=sheets,
        grid=[8,8],frame_count=64,license='MIT; authored scene, code and rendered effect',
        status='COMPLETED native scene and flipbooks; native Bevy playback; experimental Three.js adapter',
        native_scene=(ROOT/'spiky_explosion.blend').relative_to(PACK).as_posix())
    (ROOT/'effect.json').write_text(json.dumps(meta,indent=2)+'\n')
    for folder in [ROOT]:
        files=sorted(p for p in folder.rglob('*') if included(p) and p!=folder/'SHA256SUMS.txt')
        (folder/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(folder).as_posix()}\n' for p in files))
    for folder,target in [(ROOT,args.archive)]:
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in sorted(folder.rglob('*')):
                if included(p):z.write(p,Path(folder.name)/p.relative_to(folder))
        with zipfile.ZipFile(target) as z:assert z.testzip() is None
        target.with_suffix('.zip.sha256').write_text(f'{sha(target)}  {target.name}\n')
        print(json.dumps(dict(zip=str(target),MiB=round(target.stat().st_size/1024**2,2),sha256=sha(target),crc='PASS')))
if __name__=='__main__':main()
